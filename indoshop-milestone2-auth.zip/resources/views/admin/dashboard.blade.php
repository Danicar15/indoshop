@extends('layouts.app')

@section('title', 'پنل مدیریت')

@section('content')
<section class="page-banner">
    <div class="container"><span class="eyebrow">مدیریت فروشگاه</span><h1>پنل مدیریت</h1><p>خوش اومدی {{ auth()->user()->name }}.</p></div>
</section>
<section class="section container">
    <div class="admin-stats">
        <article><span>کل محصولات</span><strong>{{ $productsCount }}</strong></article>
        <article><span>دسته‌بندی‌ها</span><strong>{{ $categoriesCount }}</strong></article>
        <article><span>مشتری‌ها</span><strong>{{ $customersCount }}</strong></article>
    </div>
    <p class="auth-intro">این داشبورد پایه است. مدیریت محصولات، دسته‌بندی‌ها و سفارش‌ها در مراحل بعدی اضافه می‌شود.</p>
</section>
@endsection
